#!/bin/sh
./jre1.5.0_05/bin/java -jar SAM-bin.jar
